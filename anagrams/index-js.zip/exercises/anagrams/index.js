// --- Directions
// Check to see if two provided strings are anagrams of eachother.
// One string is an anagram of another if it uses the same characters
// in the same quantity. Only consider characters, not spaces
// or punctuation.  Consider capital letters to be the same as lower case
// --- Examples
//   anagrams('rail safety', 'fairy tales') --> True
//   anagrams('RAIL! SAFETY!', 'fairy tales') --> True
//   anagrams('Hi there', 'Bye there') --> False

function anagrams(stringA, stringB) {
  let stra = stringA.replace(/[^a-z]/gi, '').toLowerCase().split('');
  let strb = stringB.replace(/[^a-z]/gi, '').toLowerCase().split('');

  compareA = {};
  compareB = {};

  function compareStrings(element) {

  }

  for (let char of stra)  {
    if (!compareA[char]) {
      compareA[char] = 1
    } else {
      compareA[char] += 1
    }
  }

  for (let char of strb)  {
    if (!compareB[char]) {
      compareB[char] = 1
    } else {
      compareB[char] += 1
    }
  }

  for (let char in compareA) {
    if (compareA.keys(obj).length !== compareB.keys(obj).length || compareA[char] !== compareB[char]) {
      return false
    }
  }



  return compareB
}

module.exports = anagrams;
